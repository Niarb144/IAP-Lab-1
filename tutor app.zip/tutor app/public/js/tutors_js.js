$('.body').vegas({
    slides: [{
        src: '/assets/images/slide1.jpg'
    }, {
        src: '/assets/images/slide2.jpg'
    }, {
        src: '/assets/images/slide3.jpg'
    }, {
        src: '/assets/images/slide4.jpg'
    }]
});



$(document).ready(function() {
    
    // $(document).on("click", function(){
        // $('.sub-main').addClass('animated rollOut');
        // $('.header-bg').addClass('animated rollOut');
    // });

    // var animationName = "";
    // var animationEnd = "";
    // $("#student-header1").addClass(animationName);

});
